"""Strict isolated filesystem observation. No PID attribution is inferred."""
from pathlib import Path
import ctypes
import hashlib
import os
import select
import signal
import stat
import struct
import subprocess
import time

MASK=0x2|0x4|0x8|0x40|0x80|0x100|0x200|0x400|0x800

class Watch:
    def __init__(self,scope):
        self.scope=Path(scope).absolute()
        if self.scope.resolve()!=self.scope or not self.scope.is_dir():
            raise RuntimeError('explicit existing non-symlink directory required')
        self.libc=ctypes.CDLL(None,use_errno=True)
        self.fd=self.libc.inotify_init1(os.O_NONBLOCK|os.O_CLOEXEC)
        if self.fd<0:raise OSError(ctypes.get_errno(),'inotify_init1 failed')
        self.watches={};self.events=[];self.errors=[];self.dynamic_watches=0
        try:
            self.add(self.scope.parent)
            self.add_tree(self.scope)
        except BaseException:
            os.close(self.fd);raise
    def __enter__(self):return self
    def __exit__(self,*args):os.close(self.fd)
    def add(self,path):
        if path.is_symlink():raise RuntimeError('symlink watch unsupported')
        if path in self.watches.values():return
        wd=self.libc.inotify_add_watch(self.fd,os.fsencode(path),MASK|0x01000000|0x02000000)
        if wd<0:raise OSError(ctypes.get_errno(),'watch registration failed')
        self.watches[wd]=path
    def add_tree(self,path):
        def fail(error):raise error
        for d,dirs,files in os.walk(path,followlinks=False,onerror=fail):
            if any((Path(d)/n).is_symlink() for n in dirs+files):
                raise RuntimeError('symlink in protected scope')
            self.add(Path(d))
    def drain(self):
        while True:
            try:data=os.read(self.fd,1024*1024)
            except BlockingIOError:return
            if not data:self.errors.append('WATCH_EOF');return
            offset=0
            while offset<len(data):
                if offset+16>len(data):self.errors.append('MALFORMED_EVENT');return
                wd,mask,cookie,n=struct.unpack_from('iIII',data,offset);offset+=16
                if offset+n>len(data):self.errors.append('MALFORMED_EVENT');return
                name=os.fsdecode(data[offset:offset+n].split(b'\0')[0]);offset+=n
                if mask&0x4000:self.errors.append('QUEUE_OVERFLOW');continue
                if mask&(0x8000|0x2000):self.errors.append('WATCH_LOSS')
                if wd not in self.watches:self.errors.append('UNKNOWN_WATCH');continue
                path=self.watches[wd]/name
                if not (path==self.scope or self.scope in path.parents):continue
                self.events.append({'path':str(path),'mask':mask,'cookie':cookie,'observed_monotonic_ns':time.monotonic_ns(),'process_attribution':'NOT_ESTABLISHED'})
                if mask&0x40000000 and mask&(0x100|0x80):
                    before=len(self.watches)
                    try:self.add_tree(path)
                    except (RuntimeError,OSError):self.errors.append('DYNAMIC_WATCH_REGISTRATION_FAILED')
                    self.dynamic_watches+=len(self.watches)-before
                    # Events preceding the new watch cannot be reconstructed.
                    self.errors.append('NEW_SUBTREE_PREWATCH_INTERVAL_UNOBSERVABLE')
                if mask&(0x400|0x800):self.errors.append('WATCHED_DIRECTORY_REMOVED_OR_MOVED')

def snapshot(scope):
    rows={}
    def fail(error):raise error
    for d,dirs,files in os.walk(scope,followlinks=False,onerror=fail):
        for n in ['']+dirs+files:
            p=Path(d)/n;s=p.lstat()
            if stat.S_ISLNK(s.st_mode):raise RuntimeError('unsupported protected symlink')
            if not (stat.S_ISDIR(s.st_mode) or stat.S_ISREG(s.st_mode)):
                raise RuntimeError('unsupported protected filesystem object')
            rows[str(p)]={'sha256':hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else None,
                         'dev':s.st_dev,'inode':s.st_ino,'mode':s.st_mode,'uid':s.st_uid,'gid':s.st_gid,
                         'size':s.st_size,'mtime_ns':s.st_mtime_ns,'ctime_ns':s.st_ctime_ns,'nlink':s.st_nlink}
    return rows

def run(scope,argv,cwd,log,timeout=600,stop_on_event=True):
    started=time.time();proc=None;ready=False;timed_out=False
    with Watch(scope) as watcher:
        before=snapshot(scope);watcher.drain()
        if watcher.events or watcher.errors:raise RuntimeError('scope changed before child readiness')
        ready=True
        with Path(log).open('xb') as output:
            proc=subprocess.Popen(argv,cwd=cwd,stdout=output,stderr=subprocess.STDOUT,start_new_session=True)
            while proc.poll() is None:
                if select.select([watcher.fd],[],[],.02)[0]:watcher.drain()
                if time.time()-started>timeout or (stop_on_event and (watcher.events or watcher.errors)):
                    timed_out=time.time()-started>timeout
                    os.killpg(proc.pid,signal.SIGTERM)
                    try:proc.wait(timeout=3)
                    except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL)
                    break
            rc=proc.wait()
            # A surviving process group makes the shutdown boundary unproven.
            try:
                os.killpg(proc.pid,0)
            except ProcessLookupError:pass
            else:
                watcher.errors.append('LIVE_DESCENDANTS_AFTER_CHILD_EXIT')
                os.killpg(proc.pid,signal.SIGTERM)
            watcher.drain()
            after=snapshot(scope)
            watcher.drain()
        content=lambda rows:{p:r['sha256'] for p,r in rows.items() if r['sha256'] is not None}
        content_changed=content(before)!=content(after)
        metadata_changed=before!=after
        rejected=bool(watcher.events or watcher.errors or metadata_changed or rc or timed_out)
        return {'result':'REJECT' if rejected else 'PASS_BOUNDED_OBSERVATION',
                'scope':str(scope),'command':argv,'cwd':str(cwd),'native_exit':rc,
                'ready_before_child':ready,'final_queue_drained':True,'timed_out':timed_out,
                'events':watcher.events,'observation_errors':watcher.errors,
                'dynamic_watches':watcher.dynamic_watches,'before':before,'after':after,
                'content_changed':content_changed,'metadata_changed':metadata_changed,
                'process_attribution':'NOT_ESTABLISHED','continuous_byte_immutability':'NOT_ESTABLISHED',
                'start':started,'end':time.time(),
                'limits':'Local inotify only; no PID, mmap/remote filesystem universality or reconstruction of prewatch subtree activity. Any event/loss/metadata delta rejects; endpoint hash equality is not continuous immutability.'}
