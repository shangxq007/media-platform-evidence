from pathlib import Path
import hashlib,json,subprocess,re,zipfile
D=Path(__file__).resolve().parents[1];P=D.parent/'EP19_H7_EXTERNAL_CENSUS_INPUT_CORRECTION_AND_PRESERVATION_DRIFT_DISPOSITION_V1'
pins={'REVIEW_PACKAGE.zip':'ac484fbd05dabdd19bc2dcc58bcc93a1349bd2a6f2ad7297068cefdb6a403bbb','FINAL_REPORT.txt':'aee72e0dc6dc2fd343aac19b5104d0e6d62c04b6ccfb66d10e1fb58670ec4a5d','REVIEW_UPLOAD.txt':'6ed7efec3203dcc9854fda4c890562bb8a9e80bb01cdd88742cd3d7ca056b55d','EXTERNAL_MANIFEST.sha256':'3d19828c616b4c632bab0fe158c03dc24300cd7e296594647aaed8f29b6cceed','inputs/h7_frozen.py':'681f195f6f9fb9a27ea254e9eeea137d231a5e66820aeff4b0225c604db2c5d1','inputs/h7_adapter.py':'837dc8a585c2154ba9b69dfe904df8a1c131dc30be08bf263448e23d18ea349c','inputs/comparator.py':'457f59faefadee35bc22be8f05bb9425efaf940c127e9520d862338a6680956f'}
rows=[]
for n,v in pins.items():
 assert re.fullmatch('[0-9a-f]{64}',v)
 actual=hashlib.sha256((P/n).read_bytes()).hexdigest();assert actual==v,n
 rows.append({'path':n,'expected':v,'actual':actual,'result':'PASS'})
bad='681f195f6f9fb9a27ea254e9eeea137d231a5e66820aeff4b0225c03ed4ac2e7d2a81de91ba0a0b215'
assert not re.fullmatch('[0-9a-f]{64}',bad)
with zipfile.ZipFile(P/'REVIEW_PACKAGE.zip') as z:assert z.testzip() is None
root=Path('/home/user/Documents/workspace/projects/media-platform')
identity=subprocess.check_output(['git','--no-optional-locks','-C',str(root),'show','-s','--format=%H %T %P','86d6aef94fd5e58da552e97c11473cff6eca734e']).decode().strip()
assert identity=='86d6aef94fd5e58da552e97c11473cff6eca734e dba5e1e457af28cfca865e44f48eedabcc28aebb 2321ab36308a95e5ccb2faf99eefdf5765654a89'
inst=[root/'AGENTS.md',Path('/home/user/Documents/03-大模型上下文-精简版.md')]
result={'pinned_artifacts':rows,'canonical_publication_identity':identity,'conflicting_guard_transcription':{'literal':bad,'length':len(bad),'result':'REJECT_INVALID_SHA256_FORMAT'},'instruction_identities':[{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in inst],'instruction_scope':'AGENTS root only; no tracked nested AGENTS. No ancestor AGENTS found for external task root. Current Owner independent repository/no-delegation overrides linked-worktree default. Context records decisions, not execution proof.','disclosure_precedence':['DELIVERY_RECEIPT.json','FINAL_DELIVERY_DISPOSITION.txt'],'historical_supplemental_scan':'NOT_RUN_TOOL_CONSENT_BLOCK; prohibited invocation not retried','prior_archive_crc':'PASS'}
with (D/'AUTHORITY_VERIFICATION.json').open('x') as f:json.dump(result,f,indent=2)
print('AUTHORITY_VERIFICATION=PASS')
