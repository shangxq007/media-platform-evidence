from pathlib import Path
import csv,json,hashlib,subprocess,time,xml.etree.ElementTree as ET
D=Path(__file__).resolve().parents[1];C=D/'candidate'
def load(n):return json.loads((D/n).read_text())
def put(n,x):
 with (D/n).open('x') as f:json.dump(x,f,indent=2,sort_keys=True);f.write('\n')
raw=list(csv.DictReader((D/'FULL_TEST_EXPECTED_FROZEN.tsv').open(),delimiter='\t'))
expected_skips={(':'+r['module'].replace('/',':')+':test',r['test_class'],r['test_identity']) for r in raw if r['expected_status']=='SKIPPED'}
observed=list(csv.DictReader((D/'EXECUTED_TEST_IDENTITIES.tsv').open(),delimiter='\t'))
actual_skips={(r['task'],r['class'],r['identity']) for r in observed if r['gate']=='FULL_BACKEND' and r['status']=='SKIPPED'}
assert expected_skips==actual_skips
put('SKIP_IDENTITY_RECONCILIATION.json',{'expected':len(expected_skips),'observed':len(actual_skips),'missing':0,'unexpected':0,'identities':sorted(actual_skips)})
receipts={p.stem:json.loads(p.read_text()) for p in D.glob('*.receipt.json')};intervals=sorted((r['start'],r['end']) for r in receipts.values() if 'start' in r and 'end' in r)
merged=[]
for a,b in intervals:
 if merged and a<=merged[-1][1]:merged[-1][1]=max(merged[-1][1],b)
 else:merged.append([a,b])
b=load('BEFORE.json');a=load('AFTER_GATES.json');timing={'task_observed_seconds':a['end']-b['start'],'gate_union_seconds':sum(y-x for x,y in merged),'full_backend_seconds':load('FULL_BACKEND.receipt.json')['end']-load('FULL_BACKEND.receipt.json')['start'],'measurement':'wall clock endpoints; overlapping gates counted once in union; uninstrumented intervals not fabricated as active work or wait','full_backend_attempts':1,'full_backend_retries':0};put('TIMING.json',timing)
ci=(C/'frontend/vite.config.ts').read_text();out=[(i,l) for i,l in enumerate(ci.splitlines(),1) if 'outDir' in l or 'emptyOutDir' in l]
put('EXECUTION_DRIFT_DISPOSITION.json',{'result':'BLOCKED_EXACT_CANDIDATE_VALIDATION','candidate_commit_unchanged':True,'full_backend_native_exit':0,'full_backend_acceptance':'REJECT_TRACKED_DRIFT','tracked_paths':load('FULL_BACKEND.receipt.json')['tracked_delta_after'].splitlines(),'source_of_output_binding':{'path':'frontend/vite.config.ts','lines':out},'overlap':'FRONTEND_BUILD ran against same candidate filesystem during FULL_BACKEND; native build log names the generated backend static assets. No historical Pack writer inference.','classification':'Gate-output isolation/invocation defect; not H7 predicate or canonical business-authority semantics defect.','preserved':'No reset/restore/clean/amend/replacement commit or full retry performed.','dependent_gates_not_run':['APPLICATION_CLASSPATH','APPLICATION_PROBE','FOUNDATION','BOOTJAR'],'scope_deviation':'Frontend build output target was not recovered before launching the gate; three tracked static-resource paths changed outside the four product correction paths. Default Gradle user-home cache and /tmp were also used (FCV inventory records GRADLE_USER_HOME and TMPDIR unset); those runtime cache namespaces were not baselined. No global configuration or access-control change claimed or issued.','next_authorization':'Authorize a separate append-forward external gate-output-isolation correction: preserve this checkout and commit, run frontend gates in a disposable independent repository, perform renewed required FCV in a new exact-SHA verification checkout, and review the Pack-only versus broader historical harness preservation scope. No H7/business predicate patch, history rewrite or product publication requested.'})
info=load('CANDIDATE_IDENTITY.json');account=load('TEST_IDENTITY_ACCOUNTING.json');pres=load('PRESERVATION_REPORT.json')
text=f'''TASK=EP19_H7_PRODUCTION_INPUT_BOUNDARY_CORRECTION_AND_PACK_MONITOR_QUALIFICATION_V1
TASK_EXECUTION=BLOCKED_EXACT_CANDIDATE_VALIDATION
H7_PRODUCTION_INPUT_BOUNDARY=PASS_FOCUSED_AND_EXACT_ENTRYPOINT
H7_SEMANTIC_CONTINUITY=PASS_33_RULES_UNCHANGED
PACK_MONITOR_QUALIFICATION=PASS_13_BOUNDED_CONTROLS_NOT_FULL_HISTORICAL_HARNESS_EQUIVALENCE
PACK_HISTORICAL_BYTE_IMMUTABILITY=NOT_RECOVERABLE
CANDIDATE_BASE_SHA={info['base']}
CANDIDATE_COMMIT_SHA={info['commit']}
CANDIDATE_TREE={info['tree']}
REQUIRED_GATES=BLOCKED_REJECT_TRACKED_DRIFT
PRESERVATION_SCOPE=BOUNDED_ENDPOINTS_AND_DISCRETE_CANONICAL_PACK_WINDOWS
DELIVERY_SCAN_COVERAGE=SEE_DETACHED_DELIVERY_SCAN_RECEIPTS
EVIDENCE_DELIVERY=AUTHORIZED_CHANNEL_PREPARED_PUBLICATION_PENDING_AT_REPORT_SEAL
PRODUCT_PUBLICATION=NOT_PERFORMED
POST_PUBLICATION_SANITY=NOT_RUN
EP19_CLOSED=NO
ROADMAP_23_SECOND_WAVE=NO_GO
INDEPENDENT_REVIEW=REQUIRED

完成：四路径生产枚举边界候选已在独立对象库提交；未共享 canonical 对象库。Git-tree membership + raw-byte equality + explicit root/tree receipt，不再递归扫描 nested worktrees。接受的 308 源、122 额外源排除、settings context、确定性顺序、真实违规与重复权威检测均已聚焦资格验证。旧 external census 未重跑；历史 14/17/13/15 仅作为历史材料。所有 33 条规则与 ZERO_LAWS、parser/masking/evaluator/self-test AST 连续性保留，canonical counts/details 一致。

新执行身份对账：
'''
for k,v in account.items():text+=k+' '+ ' '.join(f'{n}={v[n]}' for n in ['expected','executed','missing','unexpected','duplicate','failed','errored','skipped','passed'])+'\n'
text+='''
核心阻塞：FULL_BACKEND native exit 0，但最终 REJECT_TRACKED_DRIFT。并行 FRONTEND_BUILD 使用 frontend/vite.config.ts 的 outDir 写入后端已跟踪 static 资源，两个旧 asset 被删除、index.html 改动，另有新未跟踪 asset。Git commit/tree 未变，不代表执行文件系统与冻结树一致；不得把 7973 身份原生测试结果提升为精确候选 FCV PASS。完整漂移及日志已保留，不回滚、不修补、不重试。ApplicationModules classpath/probe、foundation、bootJar 后续依赖门禁 NOT_RUN。

分类：这是本任务门禁输出隔离/调用缺陷，不是 H7 业务或 attribution 算法缺陷。初次 qualify_h7 helper 的 duplicate-authority 断言曾误用调用作用域计数，已在冻结前修正 reporting/test helper，失败日志保留；冻结谓词未变。原 native manifest 的 .json 文件名实际为原生 TSV；另提供字节相同 .tsv 别名，未改执行语义。

Pack：13 项控制通过，含真实队列溢出、watch loss、退出边界、write/restore、metadata-only、新目录和 stop-on-event。任意观测事件/丢失/记录元数据差异均拒绝；无 IN_ATTRIB 豁免。未建立 PID writer、连续字节不可变性、所有属性种类或权限拒绝专项复现。当前 Pack-only scope 不是对旧完整 PRIMARY/SHADOW harness 契约等价性的自我批准，具体映射需独立审查。

保全：canonical tracked/index/HEAD/refs/worktree registrations 和接受的历史 deliverables 无观测差异；.usage.json 漂移单独披露。历史四个 Skill 路径（两个内容、两个运行元数据）及一个 Memory 路径变化保留，writer NOT_ESTABLISHED。零显式 Skill/Memory 写入不证明无运行时写入。只提供哈希和有限观测，不复制 Memory 内容。默认 Gradle cache 与 /tmp 的边界限制见 EXECUTION_DRIFT_DISPOSITION.json。

交付：见 EXTERNAL_MANIFEST.sha256、ARCHIVE_VERIFICATION.json、DELIVERY_CREDENTIAL_SCAN.json 和 EVIDENCE_DELIVERY_RECEIPT.json（如远端成功）。凭据扫描仅针对本次新交付，有精确覆盖边界；没有重试上一次被拒绝的补充扫描。不声明普遍 secret absence。报告封装时远端发布尚未发生，最终不可变 URL 和远端回读在 detached receipt 中；本地路径不是 ChatGPT upload。

下一项需要的精确授权：保留当前冻结 commit 与脏执行工作区，另行进行 append-forward 外部门禁隔离修正：frontend 在独立 disposable clone 执行；另一个 exact-SHA checkout 重新执行 required FCV；同时明确 Pack-only 与原完整 preservation harness 的契约映射。此处不请求产品发布，也不请求修补 H7 业务语义。当前候选不得进入 publication，必须先解决执行隔离并重新独立审查。
'''
(D/'FINAL_REPORT.txt').write_text(text)
(D/'REVIEW_UPLOAD.txt').write_text('REVIEW_DISPOSITION=BLOCKED_EXACT_CANDIDATE_VALIDATION\n'+text+'\nREVIEW_ENTRYPOINTS=FINAL_REPORT.txt; EXECUTION_DRIFT_DISPOSITION.json; TEST_IDENTITY_ACCOUNTING.json; H7_SEMANTIC_CONTINUITY.json; MONITOR_CONTRACT.txt; CANDIDATE.diff; preservation and gate receipts.\n')
(D/'PUBLICATION_PROPOSAL.txt').write_text('NOT_AUTHORIZED_FOR_EXECUTION\nProposed product scope after successful fresh validation and independent acceptance: exact four paths in CANDIDATE_IDENTITY.json, commit '+info['commit']+' based on '+info['base']+'. No monitor helper installation into product repository is included. No business source, migration, frontend Slice1C, other EP lane or roadmap23 change. Recheck remote main ancestry immediately before a separately authorized publication; current readback is historical observation only. Proposed future recipe: preserve the accepted candidate, satisfy the exact current publication contract, integrate only by separately approved mode, read back commit/tree/parents, then run actual post-publication H7 --root canonical --tree exact-published-tree --receipt fresh-external-path, architecture guard and required publication sanity recipes from the accepted FCV inventory under qualified preservation monitoring. Do not reuse this rejected execution as publication acceptance or label unpublished-candidate checks post-publication sanity.\n')
print('REPORTS_WRITTEN_BLOCKED',timing)
