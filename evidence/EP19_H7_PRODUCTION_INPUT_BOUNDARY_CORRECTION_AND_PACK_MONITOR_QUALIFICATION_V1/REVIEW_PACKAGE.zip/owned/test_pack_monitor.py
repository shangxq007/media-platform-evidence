import importlib.util
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

class PackMonitorTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
        subprocess.run(['git','init','-q',str(self.root/'repo')],check=True)
        self.scope=self.root/'repo/.git/objects';self.pack=self.scope/'pack/a.pack'
        self.pack.write_bytes(b'PACK-fixture')
    def tearDown(self):self.tmp.cleanup()
    def execute(self,code):
        from pack_monitor import run
        result=run(self.scope,[sys.executable,'-B','-c',code],self.root,self.root/'child.log',timeout=10,stop_on_event=False)
        if os.environ.get('PACK_CONTROL_OUTPUT'):
            import json
            destination=Path(os.environ['PACK_CONTROL_OUTPUT']);destination.mkdir(parents=True,exist_ok=True)
            (destination/(self._testMethodName+'.json')).write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
        return result
    def test_read_only(self):
        r=self.execute('from pathlib import Path; Path('+repr(str(self.pack))+').read_bytes()')
        self.assertEqual(r['result'],'PASS_BOUNDED_OBSERVATION');self.assertTrue(r['ready_before_child'])
    def test_byte_write(self):
        r=self.execute('from pathlib import Path; Path('+repr(str(self.pack))+').write_bytes(b"changed")')
        self.assertEqual(r['result'],'REJECT');self.assertTrue(r['content_changed'])
    def test_metadata_only(self):
        r=self.execute('import os; os.utime('+repr(str(self.pack))+', ns=(1,1))')
        self.assertEqual(r['result'],'REJECT');self.assertFalse(r['content_changed']);self.assertTrue(r['metadata_changed'])
    def test_write_restore(self):
        r=self.execute('from pathlib import Path; p=Path('+repr(str(self.pack))+'); b=p.read_bytes(); p.write_bytes(b"transient"); p.write_bytes(b)')
        self.assertEqual(r['result'],'REJECT');self.assertFalse(r['content_changed']);self.assertTrue(r['events'])
    def test_rename(self):
        r=self.execute('from pathlib import Path; p=Path('+repr(str(self.pack))+'); p.rename(p.with_suffix(".renamed"))')
        self.assertEqual(r['result'],'REJECT');self.assertTrue(r['content_changed'])
    def test_delete(self):
        r=self.execute('from pathlib import Path; Path('+repr(str(self.pack))+').unlink()')
        self.assertEqual(r['result'],'REJECT')
    def test_replacement_same_bytes(self):
        r=self.execute('from pathlib import Path; p=Path('+repr(str(self.pack))+'); b=p.read_bytes(); p.unlink(); p.write_bytes(b)')
        self.assertEqual(r['result'],'REJECT');self.assertTrue(r['events'])
    def test_new_directory(self):
        r=self.execute('from pathlib import Path; import time; d=Path('+repr(str(self.scope/'new/deep'))+'); d.mkdir(parents=True); time.sleep(.1); (d/"object").write_bytes(b"x")')
        self.assertEqual(r['result'],'REJECT');self.assertGreater(r['dynamic_watches'],0)
    def test_shutdown_boundary(self):
        r=self.execute('import atexit; from pathlib import Path; atexit.register(lambda: Path('+repr(str(self.pack))+').write_bytes(b"exit"))')
        self.assertEqual(r['result'],'REJECT');self.assertTrue(r['final_queue_drained'])
    def test_watch_loss(self):
        from pack_monitor import Watch
        with Watch(self.scope) as w:
            wd=next(iter(w.watches));w.libc.inotify_rm_watch(w.fd,wd);w.drain()
            self.assertIn('WATCH_LOSS',w.errors)
    def test_overflow_native(self):
        from pack_monitor import Watch
        maximum=int(Path('/proc/sys/fs/inotify/max_queued_events').read_text())
        if maximum>100000: self.fail('overflow fixture exceeds bounded control budget')
        with Watch(self.scope) as w:
            for i in range(maximum+32):
                f=self.scope/('o'+str(i));f.write_bytes(b'x');f.unlink()
            w.drain();self.assertIn('QUEUE_OVERFLOW',w.errors)
    def test_stop_on_event(self):
        from pack_monitor import run
        code='from pathlib import Path; import time; Path('+repr(str(self.pack))+').write_bytes(b"x"); time.sleep(5)'
        r=run(self.scope,[sys.executable,'-B','-c',code],self.root,self.root/'stopped.log',timeout=10)
        self.assertEqual(r['result'],'REJECT');self.assertTrue(r['events']);self.assertNotEqual(r['native_exit'],0)
    def test_registration_failure(self):
        from pack_monitor import Watch
        with self.assertRaises((RuntimeError,OSError)):Watch(self.scope/'absent')

if __name__=='__main__':unittest.main(verbosity=2)
