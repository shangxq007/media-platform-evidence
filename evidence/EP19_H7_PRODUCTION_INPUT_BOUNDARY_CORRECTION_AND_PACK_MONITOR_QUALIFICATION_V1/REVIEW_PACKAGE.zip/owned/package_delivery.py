from pathlib import Path,PurePosixPath
import hashlib,json,shutil,subprocess,zipfile
D=Path(__file__).resolve().parents[1];C=D/'candidate';P=D/'delivery-payload'
assert not P.exists();P.mkdir()
excluded={'BEFORE.json','AFTER_QUALIFICATION.json','AFTER_GATES.json'}
for p in sorted(D.iterdir()):
 if p.is_file() and p.name not in excluded and p.suffix in {'.json','.txt','.tsv','.log','.diff','.bundle'}:shutil.copyfile(p,P/p.name)
for name in ['owned','monitor-controls','AFFECTED_INTEGRATION-xml','RUNTIME_PREFLIGHT-xml','FULL_BACKEND-xml']:
 for p in sorted((D/name).rglob('*')):
  if p.is_file() and p.suffix in {'.py','.json','.xml'}:
   q=P/p.relative_to(D);q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
identity=json.loads((D/'CANDIDATE_IDENTITY.json').read_text());sha=identity['commit']
for name in identity['paths']:
 q=P/'candidate-files'/name;q.parent.mkdir(parents=True,exist_ok=True)
 q.write_bytes(subprocess.check_output(['git','-C',str(C),'show',sha+':'+name]))
q=P/'historical-reference/h7-base-guard.py';q.parent.mkdir(parents=True)
q.write_bytes(subprocess.check_output(['git','-C',str(C),'show',identity['base']+':scripts/guards/h7-architecture-guard.py']))
(P/'CANDIDATE_COMMIT_OBJECT.txt').write_bytes(subprocess.check_output(['git','-C',str(C),'cat-file','commit',sha]))
(P/'PUBLIC_CONTENT_REVIEW.json').write_text(json.dumps({'result':'SCOPED_CONTENT_SELECTION_COMPLETE_SCAN_PENDING','scope':'This task reports, four committed correction files, exact incremental Git bundle, native logs/XML, helper sources and bounded hash/event evidence only. No full product repository, raw Skill/Memory bodies, old sealed package, credential environment or external vault output.','excluded_raw_snapshots':[{'name':n,'sha256':hashlib.sha256((D/n).read_bytes()).hexdigest(),'reason':'Contains unrelated repository ref inventories; retain locally. Focused preservation summary provided.'} for n in sorted(excluded)],'bundle_scope':'One commit over the accepted prerequisite base; verify bundle separately. Decoded changed files and commit object are included for content review.','engineering_status':'BLOCKED_REJECT_TRACKED_DRIFT','delivery_status':'NOT_YET_PUBLISHED'},indent=2))
print('PAYLOAD_FILES',sum(p.is_file() for p in P.rglob('*')))
