from pathlib import Path
import hashlib,json,subprocess,os,time,sys
D=Path(__file__).resolve().parents[1]
R=Path('/home/user/Documents/workspace/projects/media-platform')
P=D.parent/'EP19_H7_EXTERNAL_CENSUS_INPUT_CORRECTION_AND_PRESERVATION_DRIFT_DISPOSITION_V1'
def sha(b):return hashlib.sha256(b).hexdigest()
def record(p):
 s=p.lstat();return {'sha256':sha(os.fsencode(os.readlink(p)) if p.is_symlink() else p.read_bytes()),'size':s.st_size,'mode':s.st_mode,'inode':s.st_ino,'dev':s.st_dev,'mtime_ns':s.st_mtime_ns,'ctime_ns':s.st_ctime_ns}
def git(*a):return subprocess.check_output(['git','--no-optional-locks','-C',str(R),*a],env=dict(os.environ,GIT_NO_REPLACE_OBJECTS='1',GIT_NO_LAZY_FETCH='1'))
def observe():
 out={'start':time.time(),'tracked':{},'protected':{},'metadata':{}}
 for n in git('ls-files','-z').split(b'\0'):
  if n:out['tracked'][os.fsdecode(n)]=record(R/os.fsdecode(n))
 for args in [('show','-s','--format=%H %T %P','HEAD'),('status','--porcelain'),('for-each-ref','--format=%(refname) %(objectname)'),('worktree','list','--porcelain'),('stash','list')]:out['metadata'][' '.join(args)]=git(*args).decode()
 paths=[R/'AGENTS.md',R/'.git/index',R/'.git/HEAD',Path('/home/user/Documents/03-大模型上下文-精简版.md')]
 paths+=list((R/'.git/objects/pack').glob('*'))
 paths += [P/n for n in ['REVIEW_PACKAGE.zip','FINAL_REPORT.txt','REVIEW_UPLOAD.txt','EXTERNAL_MANIFEST.sha256','FINAL_DELIVERY_DISPOSITION.txt','inputs/h7_frozen.py','inputs/h7_adapter.py','inputs/comparator.py']]
 paths += [Path('/home/user/.hermes/skills')/n for n in ['.usage.json','.curator_ledger.jsonl','software-development/media-platform-worktree-registry-control/SKILL.md','software-development/quality-gate-independent-verification/SKILL.md']]
 paths+=list(Path('/home/user/.hermes/memories').glob('*.md'))
 for p in paths:
  if p.is_file():out['protected'][str(p)]=record(p)
 out['end']=time.time();return out
if __name__=='__main__':
 label=sys.argv[1];dest=D/(label+'.json')
 if dest.exists():raise RuntimeError('observation already exists')
 value=observe();dest.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
 print(json.dumps({'observation':str(dest),'tracked':len(value['tracked']),'protected':len(value['protected']),'start':value['start'],'end':value['end']}))
