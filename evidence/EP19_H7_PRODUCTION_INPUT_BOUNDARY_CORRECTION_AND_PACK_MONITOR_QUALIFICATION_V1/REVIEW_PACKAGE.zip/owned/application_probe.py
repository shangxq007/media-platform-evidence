from pathlib import Path
import hashlib,json,subprocess,sys,shutil
from pack_monitor import run
D=Path(__file__).resolve().parents[1];C=D/'candidate';S=Path('/home/user/Documents/workspace/projects/media-platform/.git/objects/pack')
assert json.loads((D/'FULL_BACKEND.receipt.json').read_text())['result']=='PASS_BOUNDED_OBSERVATION','Full suite prerequisite'
assert not (D/'APPLICATION_PROBE.receipt.json').exists()
source=D.parent/'EP19_EXACT_CANDIDATE_CANONICAL_PUBLICATION_AND_POST_PUBLICATION_VERIFICATION_V1/ExposureProbe.java';probe=D/'owned/ExposureProbe.java';shutil.copyfile(source,probe)
init=D/'owned/classpath.init.gradle'
init.write_text('gradle.projectsEvaluated { def p = rootProject.project(":platform-app"); p.tasks.register("ep19EvidenceClasspath") { doLast { new File("'+str(D/'classpath.txt')+'").text = p.sourceSets.test.runtimeClasspath.asPath } } }\n')
cmd=['./gradlew','-I',str(init),':platform-app:ep19EvidenceClasspath','--no-daemon','--console=plain']
inv={'candidate':'689ab9456461a8d19a72d059f5157092efc43aff','tree':'6c97c0c879aa4cd8d1c58ca338482dd8ce25eff6','classpath_command':cmd,'probe_sha256':hashlib.sha256(probe.read_bytes()).hexdigest(),'prior_probe_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'init_sha256':hashlib.sha256(init.read_bytes()).hexdigest(),'scope':'External helper changes only: current output path binding; unchanged accepted ApplicationModules probe. No post-publication sanity claim.'}
(D/'APPLICATION_PROBE_INVENTORY.json').write_text(json.dumps(inv,indent=2))
r=run(S,cmd,C,D/'APPLICATION_CLASSPATH.native.log',timeout=600);r.update(candidate=inv['candidate'],tree=inv['tree']);(D/'APPLICATION_CLASSPATH.receipt.json').write_text(json.dumps(r,indent=2));assert r['result']=='PASS_BOUNDED_OBSERVATION'
cp=(D/'classpath.txt').read_text().strip();assert cp
pins=[]
for name in cp.split(':'):
 p=Path(name)
 if p.is_file():pins.append({'path':name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(D/'RUNTIME_DEPENDENCY_IDENTITIES.json').write_text(json.dumps(pins,indent=2))
cmd=['java','--class-path',cp,str(probe)]
r=run(S,cmd,C,D/'APPLICATION_PROBE.native.log',timeout=600);r.update(candidate=inv['candidate'],tree=inv['tree'],classpath_sha256=hashlib.sha256(cp.encode()).hexdigest(),probe_sha256=inv['probe_sha256'])
text=(D/'APPLICATION_PROBE.native.log').read_text();markers=['IMPLEMENTATION_PUBLIC=false','IMPLEMENTATION_EXPOSED_COUNT=0','QUERY_EXPOSED_COUNT=1','APPLICATION_MODULES_CENSUS=PASS']
r['required_markers']=markers;r['missing_markers']=[m for m in markers if m not in text]
if r['missing_markers']:r['result']='REJECT_MISSING_APPLICATION_MARKERS'
(D/'APPLICATION_PROBE.receipt.json').write_text(json.dumps(r,indent=2));print('APPLICATION_PROBE',r['native_exit'],r['result']);sys.exit(0 if r['result']=='PASS_BOUNDED_OBSERVATION' else 1)
