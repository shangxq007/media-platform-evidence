from pathlib import Path
import ast,csv,hashlib,importlib.util,json,os,shutil,subprocess,sys,tempfile,zipfile,time
D=Path(__file__).resolve().parents[1];C=D/'candidate';P=D.parent/'EP19_H7_EXTERNAL_CENSUS_INPUT_CORRECTION_AND_PRESERVATION_DRIFT_DISPOSITION_V1';I=P/'inputs'
sys.path.insert(0,str(C/'scripts/guards'))
from h7_input_boundary import Snapshot

def sha(b):return hashlib.sha256(b).hexdigest()
def mod(n,p):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);sys.modules[n]=m;s.loader.exec_module(m);return m
def put(n,o):(D/n).write_text(json.dumps(o,indent=2,sort_keys=True)+'\n')
def git(r,*a):return subprocess.check_output(['git','-C',str(r),*a]).decode().strip()
start=time.time()
f=mod('frozen',I/'h7_frozen.py');g=mod('newguard',C/'scripts/guards/h7-architecture-guard.py')
assert sha((I/'h7_frozen.py').read_bytes())=='681f195f6f9fb9a27ea254e9eeea137d231a5e66820aeff4b0225c604db2c5d1'
assert sha((I/'h7_adapter.py').read_bytes())=='837dc8a585c2154ba9b69dfe904df8a1c131dc30be08bf263448e23d18ea349c'
with zipfile.ZipFile(P/'REVIEW_PACKAGE.zip') as z:
 for n in ['inputs/h7_frozen.py','inputs/h7_adapter.py','inputs/SNAPSHOT_SOURCE_PIN.json','inputs/H7_UNIVERSE_CANONICAL.tsv']:
  assert z.read(n)==(P/n).read_bytes(),n
old=ast.parse((I/'h7_frozen.py').read_text());new=ast.parse((C/'scripts/guards/h7-architecture-guard.py').read_text())
protected=[]
for node in old.body:
 if isinstance(node,(ast.FunctionDef,ast.ClassDef)) and node.name not in ['production_sources','repository_root','main']:
  other=next(n for n in new.body if type(n)==type(node) and n.name==node.name)
  assert ast.dump(node,include_attributes=False)==ast.dump(other,include_attributes=False),node.name
  # Stronger byte-exact body evidence, not AST-only semantic equivalence.
  assert ast.get_source_segment((I/'h7_frozen.py').read_text(),node)==ast.get_source_segment((C/'scripts/guards/h7-architecture-guard.py').read_text(),other)
  protected.append({'name':node.name,'frozen_line':node.lineno,'candidate_line':other.lineno})
assert f.ZERO_LAWS==g.ZERO_LAWS and len(f.ZERO_LAWS)==30
s=Snapshot(C,'HEAD');selected=g.production_sources(C,s)
expected={r['path']:r['sha256'] for r in csv.DictReader((I/'H7_UNIVERSE_CANONICAL.tsv').open(),delimiter='\t')}
assert len(selected)==308 and set(selected)==set(expected)
assert all(sha(v.encode())==expected[n] for n,v in selected.items())
assert sha(('\n'.join(selected)+'\n').encode())=='20787cead59b460805dc4c7e425a143b8d0768b6d507993cfe37c2174a7a7eeb'
a=f.evaluate(selected);b=g.evaluate(selected)
assert a.counts==b.counts and a.details==b.details and b.passed and len(b.counts)==33
pins=json.loads((I/'SNAPSHOT_SOURCE_PIN.json').read_text());live={n.removeprefix('live-source/'):h for n,h in pins.items() if n.startswith('live-source/') and n!='live-source/settings.gradle.kts'}
extra=sorted(set(live)-set(expected));assert len(extra)==122
cases=[]
with tempfile.TemporaryDirectory(prefix='h7-production-',dir=D) as tmp:
 r=Path(tmp);git(r,'init','-q')
 for n in [*selected,'settings.gradle.kts']:
  data=(I/'canonical-source'/n).read_bytes();dest=r/n;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
 git(r,'add','--all');tree=git(r,'write-tree')
 for n in extra:
  data=(I/'live-source'/n).read_bytes();assert sha(data)==live[n]
  dest=r/n;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
 snap=Snapshot(r,tree);clean=g.production_sources(r,snap)
 assert clean==selected
 cases.append('exact_308_plus_122_untracked_excluded_with_context')
 # No contaminated evaluate: historical reproduction remains accepted evidence.
 assert len(f.production_sources(r))==430
 cases.append('frozen_enumerator_confirms_430_fixture_membership_only')
 reverse=g.production_sources(r,Snapshot(r,tree));assert list(reverse)==sorted(selected)
 cases.append('deterministic_order')
 violation='timeline-module/src/main/java/ControlledViolation.java'
 dest=r/violation;dest.write_text('class ControlledViolation { Object x = ProductCurrentRevisionService.class; }')
 git(r,'add','--',violation);bad_tree=git(r,'write-tree')
 out=g.evaluate(g.production_sources(r,Snapshot(r,bad_tree)))
 assert not out.passed and out.counts['PRODUCT_CURRENT_REVISION_ID_PRODUCTION_USAGE_COUNT']>b.counts['PRODUCT_CURRENT_REVISION_ID_PRODUCTION_USAGE_COUNT']
 cases.append('genuine_canonical_violation_detected')
 # New independent fixture membership retains equal bytes at distinct paths.
 authority=next(n for n,v in selected.items() if 'class ProjectRevisionNumberAllocator' in v)
 duplicate='timeline-module/src/main/java/DuplicateAllocator.java'
 (r/duplicate).write_text(selected[authority]);git(r,'add','--',duplicate);dup_tree=git(r,'write-tree')
 out=g.evaluate(g.production_sources(r,Snapshot(r,dup_tree)))
 frozen_out=f.evaluate(g.production_sources(r,Snapshot(r,dup_tree)))
 assert out.counts==frozen_out.counts and out.details==frozen_out.details
 assert not out.passed and out.counts['CANONICAL_PROJECT_REVISION_ALLOCATOR_TYPE_COUNT']==2
 assert out.counts['CANONICAL_PROJECT_REVISION_ALLOCATOR_AUTHORITY_MISSING_COUNT']>0
 cases.append('duplicate_authority_detected')
put('H7_SEMANTIC_CONTINUITY.json',{'result':'PASS','protected_byte_exact_definitions':protected,'zero_laws_unchanged':True,'rules':len(b.counts),'counts':b.counts,'details':b.details,'selected':len(selected),'extra_excluded':len(extra),'extra_paths':extra,'controls':cases,'formal_external_census_rerun':False,'candidate_guard_sha256':sha((C/'scripts/guards/h7-architecture-guard.py').read_bytes()),'boundary_sha256':sha((C/'scripts/guards/h7_input_boundary.py').read_bytes()),'start':start,'end':time.time()})
put('H7_QUALIFICATION_INPUT_RECEIPT.json',s.receipt(selected))
print(json.dumps({'result':'PASS','selected':len(selected),'excluded':len(extra),'rules':len(b.counts),'controls':cases}))
