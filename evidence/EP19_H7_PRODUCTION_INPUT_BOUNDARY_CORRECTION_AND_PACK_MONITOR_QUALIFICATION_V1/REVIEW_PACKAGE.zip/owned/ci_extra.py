from pathlib import Path
import hashlib,json,subprocess,sys,os
from pack_monitor import run
D=Path(__file__).resolve().parents[1];C=D/'candidate';S=Path('/home/user/Documents/workspace/projects/media-platform/.git/objects/pack')
commands={
 'GITOPS_STAGING':['bash','scripts/validate-production-readiness.sh','gitops/staging'],
 'GITOPS_STAGING_EGRESS':['bash','scripts/verify-egress-smoke-config.sh','gitops/staging'],
 'GITOPS_PRODUCTION':['bash','scripts/validate-production-readiness.sh','gitops/production'],
 'GITOPS_PRODUCTION_EGRESS':['bash','scripts/verify-egress-smoke-config.sh','gitops/production'],
 'FRONTEND_INSTALL':['npm','ci','--cache',str(D/'npm-cache')],
 'FRONTEND_LINT':['npm','run','lint','--if-present'],
 'FRONTEND_IDENTITIES':['npx','--no-install','vitest','list','--json'],
 'FRONTEND_TEST':['npx','--no-install','vitest','run','--reporter=json','--outputFile='+str(D/'FRONTEND_TEST_RESULTS.json')],
 'FRONTEND_BUILD':['npm','run','build']}
key=sys.argv[1]
if key=='declare':
 (D/'CI_EXTRA_INVENTORY.json').write_text(json.dumps({'commands':commands,'candidate':'689ab9456461a8d19a72d059f5157092efc43aff','tree':'6c97c0c879aa4cd8d1c58ca338482dd8ce25eff6','pins':{str(p.relative_to(D)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),D/'owned/pack_monitor.py',C/'.github/workflows/ci.yml',D/'CHANGE_IMPACT.json']},'scope':'Unchanged fail-closed full_ci policy; isolated npm cache/node_modules/dist are gate outputs only. No frontend source correction, deployment or publication.'},indent=2));sys.exit(0)
inv=json.loads((D/'CI_EXTRA_INVENTORY.json').read_text());assert all(hashlib.sha256((D/n).read_bytes()).hexdigest()==v for n,v in inv['pins'].items())
if key.startswith('FRONTEND_') and key!='FRONTEND_INSTALL':
 prior={'FRONTEND_LINT':'FRONTEND_INSTALL','FRONTEND_IDENTITIES':'FRONTEND_LINT','FRONTEND_TEST':'FRONTEND_IDENTITIES','FRONTEND_BUILD':'FRONTEND_TEST'}[key]
 assert json.loads((D/(prior+'.receipt.json')).read_text())['result']=='PASS_BOUNDED_OBSERVATION','Failed prerequisite'
r=run(S,commands[key],C/'frontend' if key.startswith('FRONTEND_') else C,D/(key+'.native.log'),timeout=1200)
r.update(candidate=inv['candidate'],tree=inv['tree'],inventory_sha256=hashlib.sha256((D/'CI_EXTRA_INVENTORY.json').read_bytes()).hexdigest())
with (D/(key+'.receipt.json')).open('x') as f:json.dump(r,f,indent=2)
print(json.dumps({k:r[k] for k in ['native_exit','result']}),key)
sys.exit(0 if r['result']=='PASS_BOUNDED_OBSERVATION' else 1)
