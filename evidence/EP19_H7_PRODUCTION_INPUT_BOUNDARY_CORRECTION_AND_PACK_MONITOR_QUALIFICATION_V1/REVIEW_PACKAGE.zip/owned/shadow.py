from pathlib import Path
import subprocess,os,json,hashlib
from pack_monitor import run
D=Path(__file__).resolve().parents[1];C=D/'candidate';S=D/'shadow'
assert not S.exists()
subprocess.run(['git','clone','--no-local',str(C),str(S)],check=True)
assert not (S/'.git/objects/info/alternates').exists()
expected=subprocess.check_output(['git','-C',str(C),'rev-parse','HEAD']).strip()
assert subprocess.check_output(['git','-C',str(S),'rev-parse','HEAD']).strip()==expected
os.environ.update(PYTHONDONTWRITEBYTECODE='1',GIT_OPTIONAL_LOCKS='0')
r=run(Path('/home/user/Documents/workspace/projects/media-platform/.git/objects/pack'),['bash','scripts/verify-pfirr1-jooq-authority-fail-closed.sh'],S,D/'SHADOW_NATIVE.log',timeout=600)
lines=(D/'SHADOW_NATIVE.log').read_text().splitlines()
r['expected_negative_controls']=3;r['observed_negative_controls']=sum(x.startswith('PASS: ') and 'rejects missing authority' in x for x in lines)
r['shadow_tracked_delta']=subprocess.check_output(['git','--no-optional-locks','-C',str(S),'diff','HEAD','--name-only']).decode()
r['candidate']=expected.decode();r['helper_sha256']=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
passed=r['result']=='PASS_BOUNDED_OBSERVATION' and r['observed_negative_controls']==3 and not r['shadow_tracked_delta']
(D/'SHADOW.receipt.json').write_text(json.dumps(r,indent=2,sort_keys=True)+'\n')
if not passed:(D/'FCV_STOP.json').write_text(json.dumps({'gate':'SHADOW','native_exit':r['native_exit'],'result':'FAIL_PREREQUISITE'})+'\n')
print(json.dumps({'gate':'SHADOW','passed':passed,'native_exit':r['native_exit'],'controls':r['observed_negative_controls']}))
raise SystemExit(0 if passed else 1)
