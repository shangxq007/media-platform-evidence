from pathlib import Path
import hashlib,json,subprocess,sys,os,tarfile
from pack_monitor import run
D=Path(__file__).resolve().parents[1];C=D/'candidate';S=Path('/home/user/Documents/workspace/projects/media-platform/.git/objects/pack')
mode=sys.argv[1]
if mode=='prepare':
 archive=Path('/home/user/Documents/workspace/audit-runs/STORAGE_M0_M1_BOUNDED_DESIGN_CORRECTION_AND_IMPLEMENTATION_V1/formal-runtime/lean-4.19.0-linux.tar.zst')
 assert hashlib.sha256(archive.read_bytes()).hexdigest()=='6fe3ce97a58f44e2b3567d455b994eacec5bfe9ae7774f2a573444480ba813fe'
 tools=D/'formal-tools';tools.mkdir()
 subprocess.run(['tar','--use-compress-program=unzstd','-xf',str(archive),'-C',str(tools)],check=True)
 assert subprocess.check_output(['podman','info','--format','{{.Host.Security.SELinuxEnabled}}']).strip()==b'false','No access-control changes authorized'
 coq='docker.io/coqorg/coq@sha256:e50d77c4c5a9aa0d76ae1b343d79c5f922da3a75054b79c5dc635895438e4674'
 raw=subprocess.check_output(['podman','image','inspect',coq,'--format','{{.Id}}']).decode().strip()
 assert raw=='b80d66c91b4da3a1b3c5d3e6672cf8f4ab72ed2f7a6a1f0cf7d3aef747cf6a4b'
 inv={'commands':{'FORMAL':['bash','scripts/formal/validate-faof2.sh'],'SEMGREP':['podman','run','--rm','--network=none','-v',str(C)+':/src:ro','-w','/src','32381bb408fd23cdeb6d870a7c3c13eb247a7f7c876b92f0e134474bcfc753c0','semgrep','scan','--metrics=off','--disable-version-check','--error','--config','.semgrep/media-platform-architecture.yml','.']},'environment':{'LEAN':str(tools/'lean-4.19.0-linux/bin/lean'),'COQ_CONTAINER_ENGINE':'podman','COQ_IMAGE':coq},'candidate':'689ab9456461a8d19a72d059f5157092efc43aff','tree':'6c97c0c879aa4cd8d1c58ca338482dd8ce25eff6','coq_image_id_raw':raw,'coq_id_scheme':'Podman returns unprefixed image ID; exact digest bytes match workflow image identity','selinux_enabled':False,'lean_archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'pins':{str(p.relative_to(D)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),D/'owned/pack_monitor.py',C/'scripts/formal/validate-faof2.sh',C/'.semgrep/media-platform-architecture.yml']}}
 with (D/'PROOF_GATE_INVENTORY.json').open('x') as f:json.dump(inv,f,indent=2)
 print('PROOF_PREREQUISITES=PASS');sys.exit(0)
inv=json.loads((D/'PROOF_GATE_INVENTORY.json').read_text());assert all(hashlib.sha256((D/n).read_bytes()).hexdigest()==v for n,v in inv['pins'].items())
os.environ.update(inv['environment']);os.environ['PYTHONDONTWRITEBYTECODE']='1'
r=run(S,inv['commands'][mode],C,D/(mode+'.native.log'),timeout=600);r.update(candidate=inv['candidate'],tree=inv['tree'],inventory_sha256=hashlib.sha256((D/'PROOF_GATE_INVENTORY.json').read_bytes()).hexdigest())
with (D/(mode+'.receipt.json')).open('x') as f:json.dump(r,f,indent=2)
print(mode,r['native_exit'],r['result']);sys.exit(0 if r['result']=='PASS_BOUNDED_OBSERVATION' else 1)
