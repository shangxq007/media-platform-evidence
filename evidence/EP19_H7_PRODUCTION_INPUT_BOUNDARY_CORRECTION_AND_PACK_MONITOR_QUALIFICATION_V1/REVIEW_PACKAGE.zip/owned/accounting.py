from pathlib import Path
import ast,collections,csv,hashlib,json,re,subprocess,sys,time,xml.etree.ElementTree as ET
D=Path(__file__).resolve().parents[1];C=D/'candidate'
SHA='689ab9456461a8d19a72d059f5157092efc43aff';TREE='6c97c0c879aa4cd8d1c58ca338482dd8ce25eff6';BASE='86d6aef94fd5e58da552e97c11473cff6eca734e'
def put(n,v):
 with (D/n).open('x') as f:json.dump(v,f,indent=2,sort_keys=True);f.write('\n')
def load(n):return json.loads((D/n).read_text())
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*a):return subprocess.check_output(['git','--no-optional-locks','-C',str(C),*a]).decode().strip()
def reconcile(expected,observed):
 e=set(expected);o=collections.Counter(i for i,s in observed);status=collections.Counter(s for i,s in observed)
 return {'expected':len(expected),'executed':len(observed),'missing':len(e-set(o)),'unexpected':len(set(o)-e),'duplicate':sum(v-1 for v in o.values()),'failed':status['FAIL'],'errored':status['ERROR'],'skipped':status['SKIPPED'],'passed':status['PASS'],'missing_identities':sorted(e-set(o)),'unexpected_identities':sorted(set(o)-e)}
def xmlrows(root):
 rows=[]
 for p in sorted(root.glob('**/build/test-results/test/TEST-*.xml')):
  parts=p.relative_to(root).parts;i=parts.index('build');task=':'+':'.join(parts[:i])+':test'
  x=ET.parse(p).getroot();cases=x.findall('testcase');assert int(x.attrib['tests'])==len(cases)
  for case in cases:
   identity=(task,case.attrib['classname'],case.attrib['name']);status='ERROR' if case.find('error') is not None else 'FAIL' if case.find('failure') is not None else 'SKIPPED' if case.find('skipped') is not None else 'PASS'
   rows.append((identity,status))
 return rows
assert (D/'FULL_BACKEND.receipt.json').exists(),'Wait for completed native full execution'
assert git('rev-parse','HEAD')==SHA and git('rev-parse','HEAD^{tree}')==TREE and git('rev-parse','HEAD^')==BASE
# Preserve and report dirty frozen-checkout evidence; do not restore or accept it.
tracked_drift=git('diff','HEAD','--name-only')
expected=[(r['TASK'],r['CLASSNAME'],r['TESTNAME']) for r in csv.DictReader((D/'FULL_TEST_EXPECTED_REPOSITORY_FORMAT.tsv').open(),delimiter='\t')]
observed=xmlrows(D/'FULL_BACKEND-xml');summary={'FULL_BACKEND':reconcile(expected,observed)}
with (D/'EXECUTED_TEST_IDENTITIES.tsv').open('x') as f:
 w=csv.writer(f,delimiter='\t');w.writerow(['gate','task','class','identity','status'])
 for identity,status in observed:w.writerow(['FULL_BACKEND',*identity,status])
 for label in ['AFFECTED_INTEGRATION','RUNTIME_PREFLIGHT']:
  rows=xmlrows(D/(label+'-xml'))
  class_names={'AFFECTED_INTEGRATION':{'com.example.platform.ModularityTest','com.example.platform.entitlement.api.EntitlementDecisionQueryPublicationTest','com.example.platform.identity.architecture.AuthorizationArchitectureGuardTest'},'RUNTIME_PREFLIGHT':{'com.example.platform.sandbox.BubblewrapSandboxProcessLauncherIntegrationTest','com.example.platform.sandbox.ContainerSandboxProcessLauncherIntegrationTest'}}[label]
  wanted=[i for i in expected if i[1] in class_names]
  summary[label]=reconcile(wanted,rows)
  for identity,status in rows:w.writerow([label,*identity,status])
for label,source,log in [('H7_FOCUSED',C/'scripts/guards/test_h7_input_boundary.py',D/'H7_FOCUSED.native.log'),('PACK_QUALIFICATION',D/'owned/test_pack_monitor.py',D/'PACK_QUALIFICATION_V2.log')]:
 names=[n.name for n in ast.walk(ast.parse(source.read_text())) if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')]
 rows=[(m.group(1),'PASS' if m.group(2)=='ok' else m.group(2)) for m in re.finditer(r'^(test_\S+)\s+\(.*?\)\s+\.\.\. (ok|FAIL|ERROR)$',log.read_text(),re.M)]
 summary[label]=reconcile(names,rows);summary[label]['identities']=rows
func=next(n for n in ast.parse((C/'scripts/guards/h7-architecture-guard.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='run_self_test')
mutation_names=[n.args[0].elts[0].value for n in ast.walk(func) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and isinstance(n.func.value,ast.Name) and n.func.value.id=='cases' and n.func.attr=='append']
mutations=re.findall(r'^MUTATION (\S+)=(PASS|FAIL)\b',(D/'H7_MUTATIONS.native.log').read_text(),re.M);summary['H7_MUTATIONS']=reconcile(mutation_names,mutations);summary['H7_MUTATIONS']['identities']=mutations
fe=load('FRONTEND_TEST_RESULTS.json');fe_expected=load('FRONTEND_IDENTITIES.native.log')
wanted=[(r['file'],r['name']) for r in fe_expected];rows=[]
for suite in fe['testResults']:
 for case in suite['assertionResults']:rows.append(((suite['name'],' > '.join(case['ancestorTitles']+[case['title']])),{'passed':'PASS','failed':'FAIL','pending':'SKIPPED','todo':'SKIPPED'}[case['status']]))
summary['FRONTEND']=reconcile(wanted,rows);summary['FRONTEND']['identities']=rows
put('TEST_IDENTITY_ACCOUNTING.json',summary)
(D/'FULL_EXECUTION_MANIFEST.tsv').write_bytes((D/'FULL_EXECUTION_MANIFEST.json').read_bytes())
put('MANIFEST_FORMAT_DISCLOSURE.json',{'native_path':'FULL_EXECUTION_MANIFEST.json','actual_format':'TSV, native repository writer schema; filename extension was a helper naming mistake','byte_exact_alias':'FULL_EXECUTION_MANIFEST.tsv','sha256':h(D/'FULL_EXECUTION_MANIFEST.tsv'),'no_execution_semantics_changed':True})
receipts={p.name.removesuffix('.receipt.json'):load(p.name) for p in D.glob('*.receipt.json')}
put('GATE_SUMMARY.json',{n:{k:r.get(k) for k in ['native_exit','result','start','end','command','candidate','tree','observation_errors','content_changed','metadata_changed']} for n,r in receipts.items()})
before=load('BEFORE.json');after=load('AFTER_GATES.json');drift={}
for group in ['tracked','protected','metadata']:
 drift[group]=[n for n in before[group].keys()|after[group].keys() if before[group].get(n)!=after[group].get(n)]
put('PRESERVATION_REPORT.json',{'before_interval':[before['start'],before['end']],'after_interval':[after['start'],after['end']],'tracked_observed':len(before['tracked']),'drift':drift,'bounded_pack_observations':len(receipts),'pack_events':sum(len(r.get('events',[])) for r in receipts.values()),'pack_content_changed_gates':sum(bool(r.get('content_changed')) for r in receipts.values()),'skill_memory_task_issued_writes':0,'writer':'NOT_ESTABLISHED','historical_skill_changed_paths':4,'historical_skill_content_paths':2,'historical_skill_runtime_metadata_paths':2,'historical_memory_changed_paths':1,'historical_pack_byte_immutability':'NOT_RECOVERABLE','scope_limit':'Endpoint snapshots plus discrete per-command Pack windows, not continuous task-wide immutability. New subtree prewatch gaps, lost events, metadata changes all reject. Skill/Memory bodies never copied.'})
paths=git('diff','--name-only',BASE,SHA).splitlines();put('CANDIDATE_IDENTITY.json',{'base':BASE,'commit':SHA,'tree':TREE,'parent':git('rev-parse','HEAD^'),'paths':paths,'tracked_delta':git('diff','HEAD','--name-only'),'status':git('status','--porcelain'),'object_directory':git('rev-parse','--git-path','objects'),'alternates_present':(C/'.git/objects/info/alternates').exists(),'product_publication':'NOT_PERFORMED'})
print(json.dumps({k:{a:v for a,v in r.items() if isinstance(v,int)} for k,r in summary.items()},indent=2))
