from pathlib import Path
import importlib.util,json,subprocess,hashlib,sys
D=Path(__file__).resolve().parents[1]
foundation=D.parent/'GITHUB_REVIEW_EVIDENCE_DELIVERY_FOUNDATION_AND_SLICE1C_DIAGNOSTIC_UPLOAD_V1'
p=foundation/'github_delivery.py'
spec=importlib.util.spec_from_file_location('foundation_delivery',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
env=m.authenv()
repo=m.api(['repos/shangxq007/media-platform-evidence'],env)
assert repo.returncode==0,'Evidence repository lookup failed'
r=json.loads(repo.stdout);assert r['full_name']=='shangxq007/media-platform-evidence' and not r['private'] and r['permissions']['push']
user=m.api(['user'],env);assert user.returncode==0
u=json.loads(user.stdout);assert u['login']=='shangxq007'
target=D/'evidence-repository';assert not target.exists()
remote=m.netgit(['ls-remote',m.URL,'refs/heads/main'],env)
assert len(remote.split())==2
m.netgit(['clone','--single-branch','--branch','main',m.URL,str(target)],env)
sha=subprocess.check_output(['git','-C',str(target),'rev-parse','HEAD']).decode().strip()
assert remote.split()[0]==sha
assert not (target/'.git/objects/info/alternates').exists()
receipt={'repository':r['full_name'],'public':True,'default_branch':r['default_branch'],'base_sha':sha,'remote_readback':remote,'user_login':u['login'],'user_id':u['id'],'prior_helper_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'product_remote_mutations':0,'evidence_remote_mutations':0}
with (D/'EVIDENCE_CHANNEL_READY.json').open('x') as f:json.dump(receipt,f,indent=2)
print(json.dumps(receipt))
for path in target.rglob('AGENTS.md'):
 if '.git' not in path.parts:print('EVIDENCE_INSTRUCTIONS',str(path),path.read_text())
