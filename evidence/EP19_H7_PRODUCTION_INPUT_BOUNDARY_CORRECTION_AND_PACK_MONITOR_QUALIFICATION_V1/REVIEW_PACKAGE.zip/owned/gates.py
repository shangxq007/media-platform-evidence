from pathlib import Path
import hashlib,json,os,subprocess,sys,time
from pack_monitor import run
D=Path(__file__).resolve().parents[1];C=D/'candidate';R=Path('/home/user/Documents/workspace/projects/media-platform')
SHA='689ab9456461a8d19a72d059f5157092efc43aff';TREE='6c97c0c879aa4cd8d1c58ca338482dd8ce25eff6'
COMMANDS={
 'H7_FOCUSED':['python3','-B','scripts/guards/test_h7_input_boundary.py'],
 'H7_ENTRY':['python3','-B','scripts/guards/h7-architecture-guard.py','--root',str(C),'--tree',TREE,'--receipt',str(D/'H7_PRODUCTION_INPUT_RECEIPT.json')],
 'H7_MUTATIONS':['python3','-B','scripts/guards/h7-architecture-guard.py','--root',str(C),'--tree',TREE,'--self-test'],
 'ARCHITECTURE_SYNTAX':['bash','-n','scripts/check-architecture-drift.sh'],
 'ARCHITECTURE':['bash','scripts/check-architecture-drift.sh'],
 'GRADLE_PREFLIGHT':['./gradlew','help','projects','--no-daemon','--console=plain'],
 'COMPILE':['./gradlew','compileJava','compileTestJava','--no-daemon','--rerun-tasks','--no-build-cache','--max-workers=8','--parallel','--console=plain'],
 'AFFECTED_INTEGRATION':['./gradlew',':platform-app:test','--tests','com.example.platform.ModularityTest',':entitlement-module:test','--tests','com.example.platform.entitlement.api.EntitlementDecisionQueryPublicationTest',':identity-access-module:test','--tests','com.example.platform.identity.architecture.AuthorizationArchitectureGuardTest','--no-daemon','--rerun-tasks','--no-build-cache','--max-workers=8','--console=plain'],
}
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*a):return subprocess.check_output(['git','--no-optional-locks','-C',str(C),*a]).decode().strip()
def put(n,o):
 with (D/n).open('x') as f:json.dump(o,f,indent=2,sort_keys=True);f.write('\n')
if __name__=='__main__':
 key=sys.argv[1]
 if key=='declare':
  put('GATE_INVENTORY.json',{'candidate_commit':SHA,'tree':TREE,'commands':COMMANDS,'scope':'candidate writes only; canonical Pack event monitoring plus tracked-byte endpoint observations; not post-publication sanity','stop':'any native failure or preservation observation rejection stops dependent gates; no frozen candidate repairs','monitor_sha256':h(D/'owned/pack_monitor.py'),'runner_sha256':h(Path(__file__))})
  sys.exit(0)
 if (D/'GATE_STOP.json').exists():raise RuntimeError('dependent gate blocked')
 inv=json.loads((D/'GATE_INVENTORY.json').read_text());assert inv['commands'][key]==COMMANDS[key]
 assert inv['monitor_sha256']==h(D/'owned/pack_monitor.py') and inv['runner_sha256']==h(Path(__file__))
 assert git('rev-parse','HEAD')==SHA and git('rev-parse','HEAD^{tree}')==TREE
 assert not git('diff','HEAD','--name-only')
 os.environ.update(PYTHONDONTWRITEBYTECODE='1',GIT_OPTIONAL_LOCKS='0',H7_SOURCE_TREE=TREE)
 result=run(R/'.git/objects/pack',COMMANDS[key],C,D/(key+'.native.log'),timeout=1800)
 result.update(candidate_commit=SHA,candidate_tree=TREE,guard_sha256=h(C/'scripts/guards/h7-architecture-guard.py'),boundary_sha256=h(C/'scripts/guards/h7_input_boundary.py'),tracked_delta_after=git('diff','HEAD','--name-only'),runner_sha256=inv['runner_sha256'],monitor_sha256=inv['monitor_sha256'])
 if result['tracked_delta_after']:result['result']='REJECT_TRACKED_DRIFT'
 put(key+'.receipt.json',result)
 if result['result']!='PASS_BOUNDED_OBSERVATION':put('GATE_STOP.json',{'gate':key,'native_exit':result['native_exit'],'result':result['result'],'time':time.time(),'later_dependent_gates':'NOT_RUN'})
 print(json.dumps({'gate':key,'native_exit':result['native_exit'],'result':result['result'],'duration':result['end']-result['start']}))
 sys.exit(0 if result['result']=='PASS_BOUNDED_OBSERVATION' else 1)
