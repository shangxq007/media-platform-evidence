from pathlib import Path
import csv,json,hashlib,subprocess,sys,os,time,shutil,importlib.util
from pack_monitor import run
D=Path(__file__).resolve().parents[1];C=D/'candidate';A=D.parent/'EP19_FINAL_CONTENT_VALIDATION_V1_ATTEMPT_7_SHADOW_METADATA_QUALIFIED_FULL_ACCEPTANCE'
BASE='86d6aef94fd5e58da552e97c11473cff6eca734e';SHA='689ab9456461a8d19a72d059f5157092efc43aff';TREE='6c97c0c879aa4cd8d1c58ca338482dd8ce25eff6'
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*a):return subprocess.check_output(['git','--no-optional-locks','-C',str(C),*a]).decode().strip()
def put(n,o):
 with (D/n).open('x') as f:json.dump(o,f,indent=2,sort_keys=True);f.write('\n')
def prepare():
 changed=git('diff','--name-only',BASE,SHA).splitlines()
 assert all(n in ['docs/architecture/h7-input-boundary.md','scripts/guards/h7-architecture-guard.py','scripts/guards/h7_input_boundary.py','scripts/guards/test_h7_input_boundary.py'] for n in changed)
 for n in ['FULL_TEST_EXPECTED_FROZEN.tsv','FULL_TEST_EXPECTED_REPOSITORY_FORMAT.tsv','runtime_summary.py']:
  shutil.copyfile(A/n,D/n)
 expected=list(csv.DictReader((D/'FULL_TEST_EXPECTED_FROZEN.tsv').open(),delimiter='\t'))
 identities=[(r['module'],r['test_class'],r['test_identity']) for r in expected]
 assert len(identities)==len(set(identities))
 commands={
 'RUNTIME_PREFLIGHT':['./gradlew',':sandbox-isolation-module:test','--tests','com.example.platform.sandbox.BubblewrapSandboxProcessLauncherIntegrationTest','--tests','com.example.platform.sandbox.ContainerSandboxProcessLauncherIntegrationTest','--no-daemon','--rerun-tasks','--no-build-cache','--max-workers=8','--console=plain'],
 'CLASSIFIER_TEST':['python3','-B','scripts/ci/test_change_impact_classifier.py'],
 'FULL_BACKEND':['python3','-B','scripts/ci/run_full_deterministic_backend_suite.py','--results-root',str(C),'--manifest',str(D/'FULL_EXECUTION_MANIFEST.json'),'--expected-universe',str(D/'FULL_TEST_EXPECTED_REPOSITORY_FORMAT.tsv'),'--expected-skipped',str(sum(r['expected_status']=='SKIPPED' for r in expected)),'--command','./gradlew test --no-daemon --rerun-tasks --no-build-cache --max-workers=8 --parallel --console=plain'],
 'FOUNDATION':['./gradlew','pfirr1RemediationCheck','--no-daemon','--console=plain'],
 'BOOTJAR':['./gradlew',':platform-app:bootJar','-x','test','--no-daemon','--console=plain']}
 put('FCV_STAGE2_INVENTORY.json',{'commands':commands,'expected_identities':len(identities),'expected_skips':sum(r['expected_status']=='SKIPPED' for r in expected),'derivation':'Accepted base full-suite identity inventory, with exact Git proof that all Java/test/build/config files are unchanged; expected set fixed before new full run. Historical test passes are not reused as current results.','unchanged_source_proof':changed,'pins':{n:h(D/n) for n in ['owned/fcv.py','owned/pack_monitor.py','FULL_TEST_EXPECTED_FROZEN.tsv','FULL_TEST_EXPECTED_REPOSITORY_FORMAT.tsv','runtime_summary.py']},'candidate':SHA,'tree':TREE,'environment':{k:os.environ.get(k) for k in ['GRADLE_USER_HOME','TMPDIR','JAVA_HOME','DOCKER_HOST']},'additional_classifier_requirements':json.loads((D/'CHANGE_IMPACT.json').read_text())['policy'],'additional_lanes':'Full CI remains required by unmodified fail-closed unknown classification. No narrowed classifier policy and no publication authorization. Later toolchain-dependent lanes remain pending until runtime prerequisite.'})
 print(json.dumps({'expected':len(identities),'commands':list(commands)}))
if __name__=='__main__':
 key=sys.argv[1]
 if key=='prepare':prepare();sys.exit(0)
 if (D/'FCV_STOP.json').exists() or (D/'GATE_STOP.json').exists():raise RuntimeError('STOP')
 inv=json.loads((D/'FCV_STAGE2_INVENTORY.json').read_text())
 assert all(h(D/n)==v for n,v in inv['pins'].items())
 assert git('rev-parse','HEAD')==SHA and not git('diff','HEAD','--name-only')
 os.environ.update(GIT_OPTIONAL_LOCKS='0',PYTHONDONTWRITEBYTECODE='1',H7_SOURCE_TREE=TREE)
 result=run(Path('/home/user/Documents/workspace/projects/media-platform/.git/objects/pack'),inv['commands'][key],C,D/(key+'.native.log'),timeout=2400)
 result.update(candidate=SHA,tree=TREE,inventory_sha256=h(D/'FCV_STAGE2_INVENTORY.json'),tracked_delta_after=git('diff','HEAD','--name-only'))
 if key in ['RUNTIME_PREFLIGHT','FULL_BACKEND']:
  dest=D/(key+'-xml');dest.mkdir()
  pattern='sandbox-isolation-module/build/test-results/test/TEST-*.xml' if key=='RUNTIME_PREFLIGHT' else '**/build/test-results/test/TEST-*.xml'
  for f in C.glob(pattern):
   if f.stat().st_mtime<result['start']:continue
   target=dest/f.relative_to(C);target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(f,target)
  if key=='RUNTIME_PREFLIGHT':
   spec=importlib.util.spec_from_file_location('runtime_summary',D/'runtime_summary.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
   summary=m.summarize(dest.rglob('TEST-*.xml'));put('RUNTIME_IDENTITY_RECONCILIATION.json',summary)
   if summary['result']!='PASS':result['result']='REJECT_RUNTIME_IDENTITIES'
 if result['tracked_delta_after']:result['result']='REJECT_TRACKED_DRIFT'
 put(key+'.receipt.json',result)
 if result['result']!='PASS_BOUNDED_OBSERVATION':put('FCV_STOP.json',{'gate':key,'native_exit':result['native_exit'],'result':result['result'],'later_gates':'NOT_RUN','candidate_frozen_no_repair':True})
 print(json.dumps({'gate':key,'native_exit':result['native_exit'],'result':result['result'],'duration':result['end']-result['start']}))
 sys.exit(0 if result['result']=='PASS_BOUNDED_OBSERVATION' else 1)
